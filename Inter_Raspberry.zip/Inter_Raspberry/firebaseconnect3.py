import time
import uuid
import socket
import numpy as np
import firebase_admin
import signal
import sys
from firebase_admin import credentials, db

# Inicializar Firebase
cred = credentials.Certificate("iot-app-f878d-firebase-adminsdk-fbsvc-9384c3ff98.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://iot-app-f878d-default-rtdb.firebaseio.com/'
})

# Identificación
hostname = socket.gethostname()
id_final = f"carrito_{hostname}_{uuid.uuid4().hex[:6]}"
carritos_ref = db.reference('carritos_disponibles')

# Registrar disponibilidad
carritos_ref.child(id_final).set({
    "estado": "activo",
    "hostname": hostname,
    "timestamp": int(time.time())
})
print(f"Carrito registrado como: {id_final}")

# Inicializar I2C o simulación
try:
    import smbus2 as smbus
    bus = smbus.SMBus(1)
    bus.write_quick(0x34)
except Exception as e:
    print(f"[Simulación] I2C no disponible: {e}")
    class FakeBus:
        def write_i2c_block_data(self, addr, reg, data):
            print(f"[Simulación] I2C -> Addr: {hex(addr)}, Reg: {hex(reg)}, Data: {data}")
    bus = FakeBus()

# Configuración de motores y cinemática
DIRECCION_MOTORES = 0x34
REG_VELOCIDAD_FIJA = 0x33

R = 0.048
l1 = 0.097
l2 = 0.109
W = (1 / R) * np.array([
    [1, 1, -(l1 + l2)],
    [1, 1, (l1 + l2)],
    [1, -1, (l1 + l2)],
    [1, -1, -(l1 + l2)]
])

V_MAX = 250
PWM_MAX = 100

def calcular_pwm(vx, vy, omega):
    V = np.array([vx, vy, omega])
    velocidades = np.dot(W, V)
    factor_escala = np.max(np.abs(velocidades)) / 250 if np.max(np.abs(velocidades)) > 250 else 1
    if factor_escala > 1:
        velocidades /= factor_escala
    velocidades[1] *= -1
    velocidades[2] *= -1
    pwm = np.clip((velocidades / V_MAX) * PWM_MAX, -PWM_MAX, PWM_MAX)
    return [int(p) for p in pwm]

def enviar_pwm(vx, vy, omega):
    pwm = calcular_pwm(vx, vy, omega)
    bus.write_i2c_block_data(DIRECCION_MOTORES, REG_VELOCIDAD_FIJA, pwm)

def detener_motores():
    try:
        bus.write_i2c_block_data(DIRECCION_MOTORES, REG_VELOCIDAD_FIJA, [0, 0, 0, 0])
    except:
        print("Error al detener motores")

# Manejo de terminación
def cerrar_todo(signal_received=None, frame=None):
    detener_motores()
    print("Motores apagados.")
    try:
        carritos_ref.child(id_final).delete()
        terminar_actual = db.reference(f"terminar/{id_final}")
        if terminar_actual.get() is not None:
            terminar_actual.delete()
        print("Datos en Firebase eliminados.")
    except Exception as e:
        print(f"Error eliminando datos en Firebase: {e}")

    db.reference(f"estado_conexion/{id_final}").delete()
    sys.exit(0)

signal.signal(signal.SIGINT, cerrar_todo)
signal.signal(signal.SIGTERM, cerrar_todo)

terminar_ref = db.reference(f"terminar/{id_final}")
instrucciones_ref = db.reference("robots/123456/instrucciones")

# Escuchar instrucciones
def escuchar_comandos():
    print("Escuchando comandos...")

    while True:
        now = int(time.time())

        # Mantener conexión activa
        estado_ref = db.reference(f"estado_conexion/{id_final}")
        estado_ref.set({
            "por": id_final,
            "hostname": hostname,
            "timestamp": now
        })

        # Verificar señal de terminación
        if terminar_ref.get() is True:
            print("Se recibió señal de terminación desde el cliente.")
            cerrar_todo()

        # Leer instrucciones
        data = instrucciones_ref.get()
        if isinstance(data, dict):
            movimiento = data.get("movimiento", {})
            rotacion = data.get("rotación", {})

            vx_str = movimiento.get("vx", "0")  # Valor por defecto "0" si no existe
            vy_str = movimiento.get("vy", "0")  # Valor por defecto "0" si no existe
            w_str = rotacion.get("w", "0")      # Valor por defecto "0" si no existe

            try:
                # Convertir cadenas a enteros
                vx = int(vx_str)
                vy = int(vy_str)
                w = int(w_str)

                # Enviar los valores a los motores
                enviar_pwm(vx, vy, w)
                print(f"Moviendo: vx={vx}, vy={vy}, w={w}")
                time.sleep(0.1)

            except ValueError as e:
                print(f"Error al convertir valores: {e}")
            except Exception as e:
                print(f"Error al procesar instrucciones: {e}")

        time.sleep(0.5)

# Main
try:
    escuchar_comandos()
except KeyboardInterrupt:
    print("Interrumpido.")
    cerrar_todo()
